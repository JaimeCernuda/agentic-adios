TEST TELEMETRY EXPORT
=====================

This is a test export of the Claude Code telemetry system.

Contents:
- claude-telemetry.jsonl: Simulated telemetry data
- sessions/: Session logs and interactions
- This README file

Test Data Summary:
- 1 session simulated
- 5 telemetry events generated
- MCP interactions with Adios server
- Complete session logs
