Claude Code Telemetry Export
============================

This archive contains telemetry data from a Claude Code session with Adios MCP integration.

Test Session Details:
- User performed 3 queries
- Used Adios MCP server for file analysis
- Created an analysis script
- Total cost: $0.0315
- Duration: 5 minutes

This is test data for the telemetry analysis tool.
